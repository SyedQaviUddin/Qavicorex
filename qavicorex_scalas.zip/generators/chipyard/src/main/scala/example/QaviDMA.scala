package chipyard.example

import chisel3.util._
import chisel3._
import freechips.rocketchip.regmapper._
import freechips.rocketchip.tilelink._
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.resources._
import freechips.rocketchip.subsystem._
import org.chipsalliance.cde.config.Parameters
import freechips.rocketchip.util._


case class QaviDMAParams(
  address: BigInt = 0x40000000
)

class QaviDMA(
  params: QaviDMAParams,
   beatBytes: Int
  )(implicit p: Parameters)
   extends LazyModule {

  val device =
    new SimpleDevice("qavidma", Seq("qavi,dma"))

  val node = TLRegisterNode(
    Seq(AddressSet(params.address, 4096-1)),
    device,
    "reg/control",
    beatBytes = beatBytes
  )

  lazy val module = new Impl

  


  class Impl extends LazyModuleImp(this) {

    val srcReg   = RegInit(0.U(64.W))
    val dstReg   = RegInit(0.U(64.W))
    val lenReg   = RegInit(0.U(32.W))
    val startReg = Reg(UInt(1.W))
     startReg := 1.U

    val sIdle :: sRead :: sWrite :: sDone :: Nil = Enum(4)

    val state = RegInit(sIdle)

    val copiedBytes = RegInit(0.U(32.W))

    val statusReg = Wire(UInt(2.W))

      statusReg := 0.U

    val dmaBuffer = Reg(Vec(256, UInt(32.W)))

    val readData = Reg(UInt(32.W))


       when(state === sIdle) {
        statusReg := 0.U
       }

       when(state === sRead || state === sWrite) {
        statusReg := 1.U
       }

       when(state === sDone) {
        statusReg := 2.U
       }








      
    switch(state) {

     is(sIdle) {

       when(startReg === 1.U) {
         state := sRead
       }

     }

     is(sRead) {

        readData := dmaBuffer(copiedBytes >> 2)
        state := sWrite

      }

     is(sWrite) {

       dmaBuffer((copiedBytes >> 2) + 64.U) := readData
       copiedBytes := copiedBytes + 4.U
       when(copiedBytes >= lenReg) {
        state := sDone
        }.otherwise {
        state := sRead
       }

     }

     is(sDone) {

      when(startReg === 0.U) {
        copiedBytes := 0.U
        state := sIdle
      }

     }

  }

    node.regmap(

      0x00 -> Seq(RegField(64, srcReg)),
      0x08 -> Seq(RegField(64, dstReg)),
      0x10 -> Seq(RegField(32, lenReg)),
      0x18 -> Seq(RegField(1, startReg)),
     
      0x20 -> Seq(RegField.r(2, statusReg))

    )
  }
}

  // DMA attachment trait starts here
 trait CanHavePeripheryQaviDMA { this: BaseSubsystem =>

  private val pbus = locateTLBusWrapper(PBUS)

  lazy val dma = LazyModule(
    new QaviDMA(
     QaviDMAParams(0x40000000),
     pbus.beatBytes
    )(p)
   )

  pbus.coupleTo("qavidma") {
    dma.node :=
      TLFragmenter(pbus.beatBytes, pbus.blockBytes) := _
  }
}
