package chipyard

import org.chipsalliance.cde.config.Config

class QaviLinuxConfig extends Config(
  new freechips.rocketchip.rocket.WithNBigCores(4) ++
  new freechips.rocketchip.subsystem.WithNBanks(1) ++
  new chipyard.config.AbstractConfig
)
